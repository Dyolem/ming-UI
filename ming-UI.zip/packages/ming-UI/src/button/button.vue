<script  lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'MingButton',

})
</script>

<template>
  <div>
    <button>button</button>
  </div>
</template>
