# Markdown Extension Examples

This page demonstrates some of the built-in markdown extensions provided by VitePress.
